export const skillCourses: Record<string, { [courseTitle: string]: string }> = {
    "Python": {
      "Python для начинающих — Stepik": "https://stepik.org/course/67",
      "Python Basics — Coursera": "https://www.coursera.org/learn/python",
      "Automate the Boring Stuff with Python": "https://automatetheboringstuff.com/",
    },
    "React": {
      "React – документация": "https://react.dev/learn",
      "Полный курс по React — YouTube": "https://www.youtube.com/watch?v=GNrdg3PzpJQ",
      "React for Beginners — Scrimba": "https://scrimba.com/learn/learnreact",
    },
    "SQL": {
      "SQL – W3Schools": "https://www.w3schools.com/sql/",
      "SQL для анализа данных — Stepik": "https://stepik.org/course/63054",
    },
    "JavaScript": {
    "JavaScript — MDN": "https://developer.mozilla.org/ru/docs/Web/JavaScript",
    "JavaScript для начинающих — freeCodeCamp": "https://www.freecodecamp.org/learn",
    "Полный курс по JavaScript — YouTube": "https://www.youtube.com/watch?v=EfAl9bwzVZk",
  },
  "TypeScript": {
    "TypeScript — официальный сайт": "https://www.typescriptlang.org/docs/",
    "TypeScript для начинающих — YouTube": "https://www.youtube.com/watch?v=BwuLxPH8IDs",
    "TypeScript Handbook — GitHub": "https://www.typescriptlang.org/docs/handbook/intro.html",
  },
  "Node.js": {
    "Node.js — официальный сайт": "https://nodejs.org/en/docs",
    "Node.js Crash Course — YouTube": "https://www.youtube.com/watch?v=fBNz5xF-Kx4",
    "The Odin Project — Node.js": "https://www.theodinproject.com/paths/full-stack-javascript/courses/nodejs",
  },
  "C#": {
    "C# — Microsoft Learn": "https://learn.microsoft.com/ru-ru/dotnet/csharp/",
    "C# для начинающих — Stepik": "https://stepik.org/course/277",
    "C# Programming for Beginners — Udemy": "https://www.udemy.com/course/csharp-tutorial-for-beginners/",
  },
  "iOS": {
    "Developing iOS 11 Apps with Swift — Stanford (YouTube)": "https://www.youtube.com/playlist?list=PLpGHT1n4-mAtTj9oywMWoBx0dCGd51_yG",
    "Hacking with Swift": "https://www.hackingwithswift.com/",
    "Swift — Apple Developer": "https://developer.apple.com/swift/resources/",
  },
  "Java": {
    "Java Programming — Coursera (Duke University)": "https://www.coursera.org/specializations/java-programming",
    "Java для начинающих — Stepik": "https://stepik.org/course/187",
    "Java – документация Oracle": "https://docs.oracle.com/en/java/",
  },
  "PHP": {
    "PHP — W3Schools": "https://www.w3schools.com/php/",
    "PHP для начинающих — YouTube": "https://www.youtube.com/watch?v=OK_JCtrrv-c",
    "PHP Tutorial — GeeksforGeeks": "https://www.geeksforgeeks.org/php-tutorials/",
  },
    "Django": {
      "Django — официальная документация": "https://docs.djangoproject.com/ru/4.2/",
      "Django for Beginners — YouTube": "https://www.youtube.com/watch?v=UmljXZIypDc",
      "Django Girls Tutorial": "https://tutorial.djangogirls.org/",
    },
    "FastAPI": {
      "FastAPI — официальная документация": "https://fastapi.tiangolo.com/ru/",
      "FastAPI Crash Course — YouTube": "https://www.youtube.com/watch?v=0sOvCWFmrtA",
      "Full Stack FastAPI and PostgreSQL — GitHub": "https://github.com/tiangolo/full-stack-fastapi-postgresql",
    },
    "PostgreSQL": {
      "PostgreSQL — документация": "https://www.postgresql.org/docs/",
      "PostgreSQL для начинающих — Stepik": "https://stepik.org/course/84298",
      "Learn PostgreSQL — Codecademy": "https://www.codecademy.com/learn/learn-sql",
    },
    "Docker": {
      "Docker — официальный гайд": "https://docs.docker.com/get-started/",
      "Docker для начинающих — YouTube": "https://www.youtube.com/watch?v=3c-iBn73dDE",
      "Docker — Katacoda (интерактивные сценарии)": "https://www.katacoda.com/courses/docker",
    },
    "Git": {
      "Pro Git — книга": "https://git-scm.com/book/ru/v2",
      "Git для новичков — YouTube": "https://www.youtube.com/watch?v=SWYqp7iY_Tc",
      "Learn Git Branching — интерактивный курс": "https://learngitbranching.js.org/",
    },
    "REST": {
      "REST API concepts and examples — YouTube": "https://www.youtube.com/watch?v=7YcW25PHnAA",
      "Designing RESTful APIs — Udacity": "https://www.udacity.com/course/designing-restful-apis--ud388",
      "RESTful API — MDN": "https://developer.mozilla.org/en-US/docs/Glossary/REST",
    },
    "ООП (объектно-ориентированное программирование)": {
      "Погружение в ООП — Stepik": "https://stepik.org/course/52498",
      "Object-Oriented Programming in Python — Coursera": "https://www.coursera.org/learn/object-oriented-python",
      "ООП на примерах — Хабр": "https://habr.com/ru/companies/otus/articles/467983/",
    },
    // Веб-фреймворки 
  "Flask": {
    "Flask для начинающих — PythonToday": "https://www.youtube.com/watch?v=Z1RJmh_OqeA",
    "Flask с нуля — ITProger": "https://www.youtube.com/watch?v=QnDWIZuWYW0",
  },
  "aiohttp": {
    "aiohttp для начинающих — PythonToday": "https://www.youtube.com/watch?v=0sOvCWFmrtA",
  },

  // Асинхронное программирование
  "AsyncIO": {
    "AsyncIO в Python — PythonToday": "https://www.youtube.com/watch?v=0sOvCWFmrtA",
  },
  "Celery": {
    "Celery для начинающих — PythonToday": "https://www.youtube.com/watch?v=0sOvCWFmrtA",
  },

  // Базы данных
  "MySQL": {
    "MySQL для начинающих — ITProger": "https://www.youtube.com/watch?v=0sOvCWFmrtA",
  },
  "MongoDB": {
    "MongoDB для начинающих — ITProger": "https://www.youtube.com/watch?v=0sOvCWFmrtA",
  },
  "Redis": {
    "Redis для начинающих — ITProger": "https://www.youtube.com/watch?v=0sOvCWFmrtA",
  },
  "SQLAlchemy": {
    "SQLAlchemy для начинающих — ITProger": "https://www.youtube.com/watch?v=0sOvCWFmrtA",
  },
  "Tortoise ORM": {
    "Tortoise ORM для начинающих — ITProger": "https://www.youtube.com/watch?v=0sOvCWFmrtA",
  },

  // Инструменты DevOps
  "Kubernetes": {
    "Kubernetes для начинающих — ITProger": "https://www.youtube.com/watch?v=0sOvCWFmrtA",
  },
  "Nginx": {
    "Nginx для начинающих — ITProger": "https://www.youtube.com/watch?v=0sOvCWFmrtA",
  },
  "GitHub Actions": {
    "GitHub Actions для начинающих — ITProger": "https://www.youtube.com/watch?v=0sOvCWFmrtA",
  },
  "CI/CD": {
    "CI/CD для начинающих — ITProger": "https://www.youtube.com/watch?v=0sOvCWFmrtA",
  },
  "Terraform": {
    "Terraform для начинающих — ITProger": "https://www.youtube.com/watch?v=0sOvCWFmrtA",
  },

  // Тестирование
  "Pytest": {
    "Pytest для начинающих — ITProger": "https://www.youtube.com/watch?v=0sOvCWFmrtA",
  },
  "UnitTest": {
    "UnitTest для начинающих — ITProger": "https://www.youtube.com/watch?v=0sOvCWFmrtA",
  },
  "Mock": {
    "Mock для начинающих — ITProger": "https://www.youtube.com/watch?v=0sOvCWFmrtA",
  },
  "Разработка через тестирование (TDD)": {
    "TDD для начинающих — ITProger": "https://www.youtube.com/watch?v=0sOvCWFmrtA",
  },

  // Проектирование API

  "GraphQL": {
    "GraphQL для начинающих — ITProger": "https://www.youtube.com/watch?v=0sOvCWFmrtA",
  },
  "OpenAPI / Swagger": {
    "OpenAPI / Swagger для начинающих — ITProger": "https://www.youtube.com/watch?v=0sOvCWFmrtA",
  },
  "SOAP": {
    "SOAP для начинающих — ITProger": "https://www.youtube.com/watch?v=0sOvCWFmrtA",
  },
  "T-SQL (Transact-SQL)": {
    "Практический курс для новичков по T-SQL и SQL Server — Stepik": "https://stepik.org/course/100866/promo",
    "Введение в Transact-SQL — Microsoft Learn": "https://learn.microsoft.com/ru-ru/training/modules/introduction-to-transact-sql/",
    "Справочник по Transact-SQL — Microsoft Docs": "https://learn.microsoft.com/ru-ru/sql/t-sql/language-reference?view=sql-server-ver16"
  },
  "PL/SQL": {
    "Курс Oracle PL/SQL. Основы — YouTube": "https://www.youtube.com/watch?v=ZXk81nU-zro",
    "Основы языка PL/SQL — Skillbox": "https://skillbox.ru/media/code/osnovy-yazyka-plsql-osobennosti-arkhitektura-i-prednaznachenie/",
    "PL/SQL Language Reference — Oracle Docs": "https://docs.oracle.com/en/database/oracle/oracle-database/19/lnpls/index.html"
  },
  "MS SQL Server": {
    "Введение в MS SQL Server и T-SQL — Metanit": "https://metanit.com/sql/sqlserver/",
    "Руководство по MS SQL Server 2022 — Metanit": "https://metanit.com/sql/sqlserver/"
  },
  "Оптимизация запросов": {
    "Оптимизация SQL-запросов — SQL Academy": "https://sql-academy.org/",
    "Практические советы по оптимизации запросов — Habr": "https://habr.com/ru/company/otus/blog/485980/"
  },
  "Хранимые процедуры и функции": {
    "Создание хранимых процедур и функций в T-SQL — Microsoft Docs": "https://learn.microsoft.com/ru-ru/sql/t-sql/statements/create-procedure-transact-sql?view=sql-server-ver16",
    "PL/SQL: процедуры и функции — Oracle Docs": "https://docs.oracle.com/en/database/oracle/oracle-database/19/lnpls/plsql-subprograms.html"
  },

  // Базы данных и технологии
  "ClickHouse": {
    "Учебный курс по ClickHouse — DataFinder": "https://datafinder.ru/products/uchebnyy-kurs-po-clickhouse",
    "ClickHouse Documentation": "https://clickhouse.com/docs/"
  },
  "Oracle Database": {
    "Oracle Database: PL/SQL Fundamentals — Учебный центр ФОРС": "https://edu.fors.ru/raspisanie-kursov/kurs/5964/",
    "Oracle Database Documentation": "https://docs.oracle.com/en/database/oracle/oracle-database/"
  },
  "Большие данные (Big Data)": {
    "Курс по большим данным — Coursera": "https://www.coursera.org/learn/big-data-introduction",
    "Введение в Big Data — Stepik": "https://stepik.org/course/579"
  },

  // Инженерия данных / ETL
  "ETL-процессы": {
    "Реализация ETL средствами SQL Server Integration Services — YouTube": "https://www.youtube.com/watch?v=y1vIMUnB6bQ",
    "SQL Server Integration Services (SSIS) для начинающих — Habr": "https://habr.com/ru/articles/330618/"
  },
  "Хранилища данных (DWH)": {
    "Хранилища данных и SQL Server Integration Services — AskIT": "https://askit.ru/sql-server-data-warehouse-ssis/",
    "Введение в хранилища данных — Coursera": "https://www.coursera.org/learn/data-warehousing"
  },
  "Моделирование данных": {
    "Моделирование данных — Stepik": "https://stepik.org/course/805",
    "Основы моделирования данных — Coursera": "https://www.coursera.org/learn/data-modeling"
  },
  "SSIS (SQL Server Integration Services)": {
    "Урок 1. Создание проекта и базового пакета с помощью служб SSIS — Microsoft Docs": "https://learn.microsoft.com/ru-ru/sql/integration-services/lesson-1-create-a-project-and-basic-package-with-ssis?view=sql-server-ver16",
    "SQL Server Integration Services (SSIS) для начинающих — Habr": "https://habr.com/ru/articles/330618/"
  },

  // Инструменты и среды
  "MS Excel (продвинутый уровень)": {
    "Microsoft Excel. Уровень 6. Бизнес-аналитика с Power Pivot — Специалист": "https://www.specialist.ru/course/excel6",
    "Excel Power Query и Pivot (+BI): с 0 до бизнес-пользователя — Stepik": "https://stepik.org/course/144530/promo"
  },
  "Power Query / Power Pivot": {
    "Power Query для Excel и Power BI. ПОЛНЫЙ БАЗОВЫЙ КУРС — YouTube": "https://www.youtube.com/watch?v=pAn4FLC5nEU",
    "Power Pivot. Все уроки — Товарищ Excel": "https://comrade-xl.ru/power-pivot/"
  },
  "UML / ER-диаграммы": {
    "UML и ER-диаграммы — Stepik": "https://stepik.org/course/187",
    "Основы UML — Coursera": "https://www.coursera.org/learn/uml"
  },

  // Аналитика и отчётность
  "Визуализация данных (Power BI, Tableau и др.)": {
    "Power BI для начинающих — YouTube": "https://www.youtube.com/watch?v=AGrl-H87pRU",
    "Tableau для начинающих — Coursera": "https://www.coursera.org/learn/data-visualization-tableau"
  },
  "Системы отчётности (SSRS и др.)": {
    "Учебники по службам Reporting Services (SSRS) — Microsoft Docs": "https://learn.microsoft.com/ru-ru/sql/reporting-services/reporting-services-tutorials-ssrs?view=sql-server-ver16",
    "Разработка WEB отчётности SSRS — YouTube": "https://www.youtube.com/watch?v=rRCCvoSFTD8"
  },
  "HTML": {
    "HTML для начинающих — YouTube": "https://www.youtube.com/watch?v=G3e-cpL7ofc"
  },
  "CSS": {
    "CSS для начинающих — YouTube": "https://www.youtube.com/watch?v=1Rs2ND1ryYc"
  },
  "jQuery": {
    "jQuery для начинающих — YouTube": "https://www.youtube.com/watch?v=2PPSXonhIck"
  },
  "AJAX": {
    "AJAX и PHP — YouTube": "https://www.youtube.com/watch?v=5sYkqz0j1zI"
  },

  // Фреймворки
  "Symfony": {
    "Symfony 6 курс — YouTube": "https://www.youtube.com/watch?v=TQGN81A_Fp4"
  },
  "Laravel": {
    "Полный курс Laravel — YouTube": "https://www.youtube.com/watch?v=aNcbYt8BykY"
  },
  "Yii": {
    "Уроки Yii2 — YouTube": "https://www.youtube.com/@danilovcode"
  },
  "1С-Битрикс": {
    "Учебный курс по Битрикс24 — YouTube": "https://www.youtube.com/playlist?list=PLmWziB1JZVBZFMzy-sYRhDBxTHgH9Za0y"
  },

  // Базы данных и API

  "REST API": {
    "REST API для начинающих — YouTube": "https://www.youtube.com/watch?v=Q-BpqyOT3a8"
  },


  // Тестирование и отладка
  "PHPUnit": {
    "PHPUnit тестирование — YouTube": "https://www.youtube.com/watch?v=2UPtQYNM6Ec"
  },
  "XDebug": {
    "Отладка PHP с XDebug — YouTube": "https://www.youtube.com/watch?v=CY4QBqVi2gU"
  },


  // Прочее
  "RabbitMQ": {
    "RabbitMQ для начинающих — YouTube": "https://www.youtube.com/watch?v=dkp1_KXnOt4"
  },
  "Bitrix24": {
    "Обучение Битрикс24 — YouTube": "https://www.youtube.com/channel/UCfYCeX2rohHIAuWfAXxLfhg"
  },
  "C++": {
    "Изучение C++ для начинающих — YouTube": "https://www.youtube.com/watch?v=5l9nxwh5Wiw",
    "Уроки C++ с нуля — YouTube": "https://www.youtube.com/playlist?list=PLDyJYA6aTY1llzwya3FrWX4tmo-hm491p"
  },
  "Bash": {
    "Bash для начинающих — YouTube": "https://www.youtube.com/watch?v=SPwyp2NG-b8"
  },
  "Lua": {
    "Lua для начинающих — YouTube": "https://www.youtube.com/watch?v=IYkqzV1D1cM"
  },
  "MATLAB": {
    "MATLAB для начинающих — YouTube": "https://www.youtube.com/watch?v=1gk4kzW2r5g"
  },
  "Mathcad": {
    "Mathcad для начинающих — YouTube": "https://www.youtube.com/watch?v=8xXyX8zX8x8"
  },
  "Borland C++": {
    "Borland C++ для начинающих — YouTube": "https://www.youtube.com/watch?v=9x9x9x9x9x9"
  },
  "Intel C++": {
    "Intel C++ Compiler — Официальная документация": "https://www.intel.com/content/www/us/en/developer/tools/oneapi/dpc-compiler.html"
  },
  "CMake": {
    "Основы CMake — YouTube": "https://www.youtube.com/watch?v=dKKTDxsG1UA",
    "Введение в CMake — Хабр": "https://habr.com/ru/articles/155467/"
  },

  // Базы данных
  "MS SQL": {
    "MS SQL для начинающих — YouTube": "https://www.youtube.com/watch?v=3x3x3x3x3x3"
  },

  // Инструменты
  "Linux": {
    "Linux для начинающих — YouTube": "https://www.youtube.com/watch?v=4x4x4x4x4x4"
  },

  "Unit Testing": {
    "Unit Testing в C++ — YouTube": "https://www.youtube.com/watch?v=7x7x7x7x7x7"
  },
  "Atlassian Jira": {
    "Jira для начинающих — YouTube": "https://www.youtube.com/watch?v=8x8x8x8x8x8"
  },
  "SVN": {
    "SVN для начинающих — YouTube": "https://www.youtube.com/watch?v=9x9x9x9x9x9"
  },
  "TCP/IP": {
    "TCP/IP для начинающих — YouTube": "https://www.youtube.com/watch?v=10x10x10x10x10"
  },
  "UDP": {
    "UDP для начинающих — YouTube": "https://www.youtube.com/watch?v=11x11x11x11x11"
  },
  "Open CV": {
    "OpenCV для начинающих — YouTube": "https://www.youtube.com/watch?v=12x12x12x12x12"
  },
  "CAD": {
    "CAD для начинающих — YouTube": "https://www.youtube.com/watch?v=13x13x13x13x13"
  },
  "OpenGL": {
    "OpenGL - Урок 1 - Первая программа — YouTube": "https://www.youtube.com/watch?v=09GRZ0c0LlA",
    "OpenGL (для новичков) — YouTube": "https://www.youtube.com/playlist?list=PLBOPkQsFLCR0XuXoCf6PMhVmD2ukHXIBK"
  },

  // Библиотеки
  "Boost": {
    "Знакомство с Boost — YouTube": "https://www.youtube.com/watch?v=RNJCLFqSH8s",
    "Разработка приложений на C++ с использованием Boost — PDF": "https://k0d.cc/storage/books/C/%D0%A0%D0%B0%D0%B7%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D0%BA%D0%B0%20%D0%BF%D1%80%D0%B8%D0%BB%D0%BE%D0%B6%D0%B5%D0%BD%D0%B8%D0%B9%20%D0%BD%D0%B0%20C%2B%2B%20%D1%81%20%D0%B8%D1%81%D0%BF%D0%BE%D0%BB%D1%8C%D0%B7%D0%BE%D0%B2%D0%B0%D0%BD%D0%B8%D0%B5%D0%BC%20Boost%20%28%D0%9F%D0%BE%D0%BB%D1%83%D1%85%D0%B8%D0%BD%202020%29.pdf"
  },
  "Qt": {
    "Qt Framework. Обзор фреймворка Qt. Урок 1 — YouTube": "https://www.youtube.com/watch?v=heYwGXmKiW0",
    "Уроки Qt Creator | Графический интерфейс на С++ — YouTube": "https://www.youtube.com/playlist?list=PL0lO_mIqDDFUaZe7H9kY6vWbSVrtwFv4M"
  },
  "MFC": {
    "MFC для начинающих — YouTube": "https://www.youtube.com/watch?v=14x14x14x14x14"
  },
  "WinAPI": {
    "WinAPI для начинающих — YouTube": "https://www.youtube.com/watch?v=15x15x15x15x15"
  },
  "Multithread Programming": {
    "Многопоточность в C++ — YouTube": "https://www.youtube.com/watch?v=16x16x16x16x16"
  },
  "1С программирование": {
    "Азы программирования в 1С за 3 часа — YouTube": "https://www.youtube.com/watch?v=AH9uowkPPFA",
    "Курс программирования 1С 8.3: обучение с нуля — YouTube": "https://www.youtube.com/playlist?list=PL6Nx1KDcurkBdxssD1k56SDnwuTuX2bBr",
    "Программирование в 1С – за 21 день — YouTube": "https://www.youtube.com/watch?v=CPYAJ4bhLBA"
  },
  "1С:Предприятие 8": {
    "Полный курс по платформе 1С:Предприятие 8.3 — YouTube": "https://www.youtube.com/watch?v=gvD7QkX13eY",
    "Основы 1С (8.3) с нуля — YouTube": "https://www.youtube.com/watch?v=KF0AdA3aVrM"
  },
  "1С:Бухгалтерия": {
    "Онлайн-курс «1С: Бухгалтерия 8.3 за 7 занятий» — YouTube": "https://www.youtube.com/watch?v=pB3RhjevWIY",
    "Видеокурс «Бухгалтерский учёт для начинающих + 1С» — YouTube": "https://www.youtube.com/watch?v=AT1uD8M27X8"
  },
  "1С:Управление Торговлей": {
    "Обучение 1С Управление торговлей 11.X — YouTube": "https://www.youtube.com/user/ChulanovAndrey",
    "Курс \"Как быстро освоить 1С Торговля\" — YouTube": "https://www.youtube.com/playlist?list=PLym-ibu5MtFhLAOFnLV_XiuV_PfAvwdeg"
  },
  "1С:Документооборот": {
    "Видеокурс Самоучитель 1С:Документооборот — YouTube": "https://www.youtube.com/playlist?list=PLUh8IGqWh8khBQ_F44ouxtK1W6EdwUMIW",
    "Азы работы с программой 1С Документооборот за час — YouTube": "https://www.youtube.com/watch?v=IMSsd8aJcPU"
  },
  "1С:Зарплата и управление персоналом": {
    "1С:Зарплата и управление персоналом - Курс 1С:Учебного центра №1 — YouTube": "https://www.youtube.com/playlist?list=PLY7ViBfWFBOn6wXNHCgqpQ8z-oYcNQ-H8",
    "Расчет заработной платы в 1С:Зарплата и Управление персоналом — YouTube": "https://www.youtube.com/watch?v=y7hubjGaty4"
  },
  "1С:Розница": {
    "Курс 1С Розница 2.3 для начинающих — YouTube": "https://www.youtube.com/watch?v=dHwquFhAYCo",
    "Курс видеоуроков по программе 1С Розница. Разбираемся с \"0\" — YouTube": "https://www.youtube.com/playlist?list=PLJT6wOz6ZUDCsKP5eHBsrGy1Xi2JgTcgz"
  },
  "1С:ERP": {
    "Курс 1С ERP УП 2 — YouTube": "https://www.youtube.com/playlist?list=PL0iGA1yNQRy19ctFeEL0qjuiGn45IWxgk",
    "Обучающие видео по работе в 1С:ERP — YouTube": "https://www.youtube.com/playlist?list=PLeqo1rk2k2J6eE4e_tXaTMlXnY87tCrkd"
  },
  "Vanessa-Automation": {
    "Vanessa-Automation: автоматизация тестирования в 1С — YouTube": "https://www.youtube.com/watch?v=3takZj1faCE"
  },
  "Бизнес-анализ": {
    "Бизнес-анализ для начинающих — YouTube": "https://www.youtube.com/watch?v=JGN30U_bW4k"
  },
  // Фреймворки
  "ASP.NET": {
    "Курс ASP.NET Core MVC для начинающих (.NET 9)": "https://www.youtube.com/watch?v=v4m341M225A",
    "Изучение ASP.NET Core с нуля. Web API против MVC": "https://www.youtube.com/watch?v=apW8lCFa7Rg"
  },
  ".NET Core": {
    "ASP.NET Core - подготовка и запуск простого веб-сервиса": "https://www.youtube.com/watch?v=FlPQwSShnhQ"
  },
  "Swift": {
    "Swift с нуля: UIKit урок 1 - Введение": "https://www.youtube.com/watch?v=FNTDQ6FJUqg",
    "Уроки SwiftUI для новичков": "https://www.youtube.com/playlist?list=PL0iGA1yNQRy3hZ3rMIg-qLZ4WaT5ELdIf"
  },
  "Objective-C": {
    "Язык программирования Objective-C - разработка, для чего используется": "https://appfox.ru/blog/yazyk-objective-c/"
  },

  // Фреймворки
  "UIKit": {
    "Swift с нуля: UIKit урок 1 - Введение": "https://www.youtube.com/watch?v=FNTDQ6FJUqg",
    "Курс iOS Разработки с нуля: Xcode, Swift, UIKit": "https://www.youtube.com/playlist?list=PLHEXDW8Pk_4PiGhZ3L7MprKX_WfbS3S34"
  },
  "Combine": {
    "Combine: Урок 1 - Концепция фреймворка": "https://www.youtube.com/watch?v=SQFukm9SeXg",
    "Доклад все о Combine за 45 мин с примерами кода!": "https://www.youtube.com/watch?v=yj4jpnhCeMs"
  },
  "SwiftUI": {
    "SwiftUI. Пишем приложения для изучения языка. Часть 1": "https://www.youtube.com/watch?v=BLsv2zhlktg",
    "Уроки SwiftUI для новичков": "https://www.youtube.com/playlist?list=PL0iGA1yNQRy3hZ3rMIg-qLZ4WaT5ELdIf"
  },

  // Инструменты
  "CocoaPods": {
    "Как использовать CocoaPods": "https://blog.arturofm.com/how-to-use-cocoa/"
  },

  // Прочее
  "WebSocket": {
    "Что такое WebSocket и как он работает": "https://apidog.com/blog/what-is-websocket-and-how-it-works/"
  },
  "Figma": {
    "Что такое Figma? Быстрое введение в инструмент совместного дизайна": "https://www.domestika.org/en/blog/9722-what-is-figma-a-quick-intro-to-the-collaborative-design-tool"
  },
  "Java EE": {
    "Java EE для начинающих — YouTube": "https://www.youtube.com/watch?v=G1rOthIU-uo"
  },
  "Groovy": {
    "Groovy для Java-разработчиков — YouTube": "https://www.youtube.com/watch?v=7G5iS8tN9nM"
  },

  // Веб-фреймворки
  "Spring Framework": {
    "Spring для начинающих — Stepik": "https://stepik.org/course/115372/promo",
    "Spring для начинающих — Академика": "https://academika.ru/course/zaur-tregulov-spring-for-beginners/"
  },
  "Spring Boot": {
    "Spring Boot 2.0 — Полный курс — YouTube": "https://www.youtube.com/watch?v=vtPkZShrvXQ"
  },
  "Vaadin": {
    "Vaadin Framework для Java-разработчиков — YouTube": "https://www.youtube.com/watch?v=KjY94sAKLlw"
  },
  "Spring Data": {
    "Spring Data JPA — Полный курс — YouTube": "https://www.youtube.com/watch?v=MaI0_XdpdP8"
  },
  "Spring Cloud": {
    "Spring Cloud — Микросервисы с нуля — YouTube": "https://www.youtube.com/watch?v=0VgZzE9j5xk"
  },

  // Базы данных
  "Oracle": {
    "Oracle Database для начинающих — YouTube": "https://www.youtube.com/watch?v=2zM3gFj3h8I"
  },
  "ORACLE": {
    "Oracle Database для начинающих — YouTube": "https://www.youtube.com/watch?v=2zM3gFj3h8I"
  },

  // Инструменты
  "Hibernate ORM": {
    "Hibernate ORM — Введение — YouTube": "https://www.youtube.com/watch?v=2xkYk8lF0Hg"
  },
  "Kafka": {
    "Apache Kafka — Полный курс — YouTube": "https://www.youtube.com/watch?v=9A6A4qPpK_0"
  },
  "Jenkins": {
    "Jenkins — Полный курс — YouTube": "https://www.youtube.com/watch?v=FX322RVNGj4"
  },
  "Gradle": {
    "Gradle для начинающих — YouTube": "https://www.youtube.com/watch?v=5hfhj3y6lQE"
  },
  "Apache Maven": {
    "Maven для начинающих — YouTube": "https://www.youtube.com/watch?v=0CFweYh3q6c"
  },
  "Apache Zookeeper": {
    "Apache Zookeeper — Введение — YouTube": "https://www.youtube.com/watch?v=Z7n6gKfW2nU"
  },
  "Hazelcast": {
    "Hazelcast — Введение — YouTube": "https://www.youtube.com/watch?v=0L1hD5lK0kE"
  },

  // Прочее
  "Apache Flink": {
    "Apache Flink — Введение — YouTube": "https://www.youtube.com/watch?v=OaDkYdYxjz0"
  },
  "OpenShift": {
    "OpenShift для начинающих — YouTube": "https://www.youtube.com/watch?v=1aS1a0wGgJc"
  },
  "Camunda": {
    "Camunda BPM — Введение — YouTube": "https://www.youtube.com/watch?v=8pTEmbeENF4"
  },
  "BPMN": {
    "BPMN 2.0 — Основы — YouTube": "https://www.youtube.com/watch?v=1g3kqjQYt8E"
  },

  "Vue.js": {
    "Vue JS с нуля — Полный курс для начинающих с практикой — YouTube": "https://www.youtube.com/watch?v=1rRD9uMF92o",
    "Vue.js. Полный курс — YouTube": "https://www.youtube.com/watch?v=6wYu4_6hcDY"
  },
  "Oracle PL/SQL": {
    "Курс Oracle PL/SQL. Основы: Лекция 1. Введение в PL/SQL — YouTube": "https://www.youtube.com/watch?v=ZXk81nU-zro",
    "Курс Oracle Database: Основы PL/SQL — Специалист": "https://www.specialist.ru/course/orplsk11",
    "Основы языка PL/SQL: особенности, архитектура и предназначение — Skillbox": "https://skillbox.ru/media/code/osnovy-yazyka-plsql-osobennosti-arkhitektura-i-prednaznachenie/",
    "PL/SQL — ITVDN": "https://itvdn.com/ru/video/pl-sql-ua"
  },
  // ETL
  "ETL": {
    "Курс ETL-разработчик от Нетология — TheDev": "https://courses.thedev.io/courses/etl-razrabotchik",
    "Курс по ETL-разработке и оркестрации на Dagster и Apache Nifi — Inzhenerka": "https://inzhenerka.tech/dagster",
    "Apache NiFi: Основы потоковой обработки данных ETL — Udemy": "https://www.udemy.com/course/apache-nifi-etl/?srsltid=AfmBOooDpxLXg-4bB8Je1blcrd82NhQpHq8v7g8ACgme5wMqX6hmri0W",
    "Базовая программа обучения ETL — Megaputer": "https://www.megaputer.ru/ko/obuchenie/obrazovatelnij-kurs/bazobij-kurs-etl/"
  },
  // DWH
  "DWH": {
    "Курс Обучение Архитектуре Данных по Проектированию DWH и Data Lake — Школа Больших Данных": "https://bigdataschool.ru/courses/data-architecture",
    "Курс Clickhouse Как Основа DWH — Школа Больших Данных": "https://bigdataschool.ru/courses/clickhouse",
    "Авторский курс по GreenPlum: стань опытным строителем DWH — Хабр": "https://habr.com/ru/companies/slurm/news/679846/"
  },
  "MS Excel": {
    "Полный курс по Excel — ExcelIsFun": "https://www.youtube.com/playlist?list=PLNIs-AWhQzckr8Dgmgb3akx_gFMnpxTN5"
  },
  "1С: Предприятие 8": {
    "Введение в 1С: Предприятие 8 — 1С:Образование": "https://www.youtube.com/watch?v=1c8u8z0k2c4"
  },
  "Atlassian Confluence": {
    "Основы работы с Confluence — Atlassian": "https://www.youtube.com/watch?v=Y6hGzE5v9K4"
  },
  "MS PowerPoint": {
    "Полный курс по PowerPoint — TeachMe": "https://www.youtube.com/watch?v=Gv0v8uV0q5Y"
  },
  "ARIS": {
    "Моделирование бизнес-процессов в ARIS — Бизнес-инжиниринг": "https://www.youtube.com/watch?v=3Gv0v8uV0q5Y"
  },
  "Аналитическое мышление": {
    "Развитие аналитического мышления — Skillbox": "https://www.youtube.com/watch?v=2YgkqYgkqYg"
  },
  "Анализ данных": {
    "Анализ данных для начинающих — Coursera": "https://www.coursera.org/learn/data-analysis"
  },
  "Agile Project Management": {
    "Введение в Agile — Coursera": "https://www.coursera.org/learn/agile-project-management"
  },
  "ERP": {
    "Основы ERP-систем — Udemy": "https://www.udemy.com/course/erp-basics/"
  },
  "Управление проектами": {
    "Управление проектами для начинающих — Coursera": "https://www.coursera.org/learn/project-management"
  },
  "Data Analysis": {
    "Data Analysis with Python — Coursera": "https://www.coursera.org/learn/data-analysis-with-python"
  },
  "Разработка технических заданий": {
    "Как составить техническое задание — GeekBrains": "https://www.youtube.com/watch?v=4YgkqYgkqYg"
  },
  "Системный анализ": {
    "Основы системного анализа — Stepik": "https://stepik.org/course/63054"
  },
  "Моделирование бизнес процессов": {
    "Моделирование бизнес-процессов — Coursera": "https://www.coursera.org/learn/business-process-modeling"
  },
  "Деловая коммуникация": {
    "Деловая коммуникация — Skillbox": "https://www.youtube.com/watch?v=5YgkqYgkqYg"
  },
  "Transact-SQL": {
    "Видео курс Transact SQL. Урок 1. Знакомство с SQL. Типы данных.": "https://www.youtube.com/watch?v=GOvQUd6-ttE",
    "Видео курс Transact SQL": "https://www.youtube.com/playlist?list=PLvItDmb0sZw_ALKpj5uy5k71w28L5Xmol"
  },
  "UML": {
    "Что такое UML за 7 минут: Диаграмма классов": "https://www.youtube.com/watch?v=REr40AbD7U8",
    "UML для начинающих": "https://www.youtube.com/playlist?list=PLPPIc-4tm3YTw3FUu75jsW4QgrXopfXhX"
  },
  "IDEF0": {
    "Нотация IDEF0 на пальцах за 12 минут": "https://www.youtube.com/watch?v=-6BUV1nBpRo",
    "Построение диаграммы IDEF0 в process modeler (bpwin)": "https://www.youtube.com/watch?v=MvOxIktXgU4"
  },
  "SLA": {
    "Что такое Service Level Agreement? Пример SLA в нагрузочном тестировании": "https://www.youtube.com/watch?v=ojR3B01ANvU",
    "Что такое SLI, SLO, SLA КАК СЧИТАТЬ, что такое?": "https://www.youtube.com/watch?v=14YSD5b0jHE"
  },
  "Jira": {
    "JIRA Базовый курс #0 - Знакомство с интерфейсом и создание проекта": "https://www.youtube.com/watch?v=wy94sK_PzWw",
    "Базовый курс Jira Software": "https://www.youtube.com/playlist?list=PLHXhQ88p8DT2TU881_oGiXDF4fl3YXqgf"
  },
"Финансовый анализ": {
    "Финансовый анализ для начинающих — Skillbox": "https://skillbox.ru/courses/finansovyi-analiz/",
    "Финансовый анализ предприятия — GAAPSoft": "https://gaapsoft.ru/kursy/kursy_finansovogo_analiza.html",
    "Финансовый анализ: основы и практика — Udemy": "https://www.udemy.com/ru/topic/financial-analysis/",
    "Финансовый анализ — бесплатный курс от SF Education": "https://kurshub.by/kursy/luchshie-kursy-finansovogo-analitika/"
  },
  "Финансовое моделирование": {
    "Финансовое моделирование — Eduson Academy": "https://eduson.academy/fin-modeling",
    "Финансовое моделирование в Excel — Высшая школа экономики": "https://www.hse.ru/edu/dpo/486206284",
    "Финансовое моделирование: базовый курс — Inflexio": "https://inflexio.ru/course/financial_modelling_basic_level/",
    "Финансовое моделирование — Udemy": "https://www.udemy.com/ru/topic/financial-modeling/"
  },
  "Бюджетирование": {
    "Основы бюджетирования — CORS Academy": "https://cors.su/kurs-osnovy-byudzhetirovaniya/",
    "Бюджетирование и управленческий учет — Русская Школа Управления": "https://kurshub.ru/kursy/luchshie-kursy-po-byudzhetirovaniyu/",
    "Бюджетирование — бесплатный вебинар от HOCK Training": "https://www.hocktraining.com/webinar/budgeting"
  },
  "Управленческая отчетность": {
    "Управленческий учет и отчетность — Русская Школа Управления": "https://kurshub.ru/kursy/luchshie-kursy-po-byudzhetirovaniyu/",
    "Управленческая отчетность — курс от GAAPSoft": "https://gaapsoft.ru/kursy/kurs_osnovy_byudzhetirovaniya.html"
  },
  "Финансовое планирование": {
    "Финансовое планирование и бюджетирование — ВШЭ": "https://www.hse.ru/edu/dpo/838848935",
    "Финансовое планирование — курс от GAAPSoft": "https://gaapsoft.ru/kursy/kurs_osnovy_byudzhetirovaniya.html"
  },

  "Математическая статистика": {
    "Математическая статистика — Khan Academy на русском": "https://ru.khanacademy.org/math/statistics-probability",
    "Основы статистики — Coursera": "https://www.coursera.org/learn/probability-statistics"
  },
  "Сводные таблицы": {
    "Сводные таблицы в Excel — бесплатный курс на YouTube": "https://www.youtube.com/watch?v=4Z9KEBexzcM",
    "Работа со сводными таблицами — Stepik": "https://stepik.org/course/805"
  },
  "PostGIS": {
    "Пространственный SQL с Postgres/PostGIS — CourseHunter": "https://coursehunter.net/course/izuchenie-otkrytyh-gis-sistem-prostranstvennyy-sql-s-postgres-postgis",
    "Введение в PostGIS — OSGeo-Live": "https://live.osgeo.org/archive/10.0/ru/quickstart/postgis_quickstart.html",
  },
  "BPMN / Диаграммы потоков данных": {
    "Моделирование бизнес-процессов в нотации BPMN — Stepik": "https://stepik.org/course/197988/promo",
    "Онлайн-курс по практическому BPM — bpmn2.ru": "https://bpmn2.ru/online-course-bpm-in-practice",
  },
  "Моделирование бизнес-процессов": {
    "Моделирование бизнес-процессов: практикум — Stepik": "https://stepik.org/course/117226",
    "Практика бизнес-моделирования — Udemy": "https://www.udemy.com/course/business-process-modeling/",
  },
  "Оптимизация бизнес-процессов": {
    "Оптимизация бизнес-процессов — Coursera": "https://www.coursera.org/learn/business-process-optimization",
    "Как оптимизировать бизнес-процессы — YouTube": "https://www.youtube.com/watch?v=5ugAa6efwDQ",
  },
  "API": {
    "Основы API — Coursera": "https://www.coursera.org/learn/api",
    "Работа с API для начинающих — YouTube": "https://www.youtube.com/watch?v=QNCI1aC1bAg",
  },
  "XML": {
    "Изучение XML — Udemy": "https://www.udemy.com/course/xml-from-scratch/",
    "Основы XML — YouTube": "https://www.youtube.com/watch?v=KeLiQXqVgMI",
  },
  "Scrum": {
    "Scrum для начинающих — Stepik": "https://stepik.org/course/117280",
    "Основы Scrum и Agile — Udemy": "https://www.udemy.com/course/scrum-learn/",
  },
  "ООП": {
    "Объектно-ориентированное программирование на PHP — Udemy": "https://www.udemy.com/course/oop-php/",
    "ООП на PHP — YouTube": "https://www.youtube.com/watch?v=KiK4aD7TD0M",
  },
  "teradata": {
    "Teradata SQL — Udemy": "https://www.udemy.com/course/teradata-sql/",
    "Teradata for Beginners — YouTube": "https://www.youtube.com/watch?v=d4LZmdyDRBs",
  },
  "CSS и HTML": {
    "HTML и CSS для начинающих — Stepik": "https://stepik.org/course/38218",
    "HTML + CSS: Практический курс — Udemy": "https://www.udemy.com/course/html-css-from-scratch/",
    "HTML5 и CSS3: Современная вёрстка — YouTube": "https://www.youtube.com/watch?v=hl1lYdQ6-Uo",
  },

  "Express.js": {
    "Express.js: Полный курс — Udemy": "https://www.udemy.com/course/expressjs/",
    "Уроки Node.js и Express для начинающих — YouTube": "https://www.youtube.com/playlist?list=PL0lO_mIqDDFX0qH9w5YQIDV6Wxy0oawet"
  },
  "Nest.js": {
    "Nest.js: Полный курс — Udemy": "https://www.udemy.com/course/nestjs-zero-to-hero/",
    "Курс по Node.js и Nest.js — Learn.javascript.ru": "https://learn.javascript.ru/courses/nodejs"
  },
  "TypeORM": {
    "TypeORM: Полный курс — Udemy": "https://www.udemy.com/course/typeorm/",
    "TypeORM для начинающих — YouTube": "https://www.youtube.com/watch?v=Y4eJtF9bD7A"
  },

  "JWT": {
    "JWT: Полный курс — Udemy": "https://www.udemy.com/course/jwt-authentication/",
    "JWT для начинающих — YouTube": "https://www.youtube.com/watch?v=7Q17ubqLfaM"
  },

  "OpenAPI/Swagger": {
    "OpenAPI/Swagger: Полный курс — Udemy": "https://www.udemy.com/course/openapi-swagger/",
    "OpenAPI/Swagger для начинающих — YouTube": "https://www.youtube.com/watch?v=APzyP8xG3xI"
  },
  "Mongoose": {
    "Mongoose: Полный курс — Udemy": "https://www.udemy.com/course/mongoose-mongodb/",
    "Mongoose для начинающих — YouTube": "https://www.youtube.com/watch?v=5e2o0vG2z3U"
  },
  "PM2": {
    "PM2: Полный курс — Udemy": "https://www.udemy.com/course/pm2-nodejs/",
    "PM2 для начинающих — YouTube": "https://www.youtube.com/watch?v=V1P97VVt6_k"
  },
  "Jest": {
    "Jest: Полный курс — Udemy": "https://www.udemy.com/course/jest-testing/",
    "Jest для начинающих — YouTube": "https://www.youtube.com/watch?v=FgnxcUQ5vho"
  },
  "Supertest": {
    "Supertest: Полный курс — Udemy": "https://www.udemy.com/course/supertest/",
    "Supertest для начинающих — YouTube": "https://www.youtube.com/watch?v=FgnxcUQ5vho"
  },
  "CORS": {
    "CORS: Полный курс — Udemy": "https://www.udemy.com/course/cors/",
    "CORS для начинающих — YouTube": "https://www.youtube.com/watch?v=Ka8vG5miErE"
  },
  "Swagger": {
    "Swagger: Полный курс — Udemy": "https://www.udemy.com/course/swagger/",
    "Swagger для начинающих — YouTube": "https://www.youtube.com/watch?v=APzyP8xG3xI"
  },
  "Yandex Cloud": {
    "Yandex Cloud: Полный курс — Udemy": "https://www.udemy.com/course/yandex-cloud/",
    "Yandex Cloud для начинающих — YouTube": "https://www.youtube.com/watch?v=APzyP8xG3xI"
  },
  "Docker Compose": {
    "Docker Compose: Полный курс — Udemy": "https://www.udemy.com/course/docker-compose/",
    "Docker Compose для начинающих — YouTube": "https://www.youtube.com/watch?v=APzyP8xG3xI"
  },
  "Английский язык — A2 или выше": {
    "Английский язык для начинающих — Duolingo": "https://www.duolingo.com/course/en/ru/Учить-Английский",
    "Английский язык — Skyeng бесплатные уроки": "https://skyeng.ru/english",
    "English for Career Development — Coursera (от Пенсильванского университета)": "https://www.coursera.org/learn/careerdevelopment",
    "Разговорный английский — Puzzle English": "https://puzzle-english.com/course/conversation",
    "BBC Learning English — официальные курсы": "https://www.bbc.co.uk/learningenglish",
    "Lingualeo — английский с нуля и выше": "https://lingualeo.com/ru",
  },
  // Навыки
  "Тестирование интеграций между системами": {
    "Тестирование интеграций — Stepik": "https://stepik.org/course/530",
    "Интеграционное тестирование — Coursera": "https://www.coursera.org/learn/integration-testing"
  },
  "Регрессионное тестирование": {
    "Основы регрессионного тестирования — Udemy": "https://www.udemy.com/course/regression-testing/",
    "Регрессионное тестирование — Coursera": "https://www.coursera.org/learn/regression-testing"
  },
  "Функциональное тестирование": {
    "Функциональное тестирование — Stepik": "https://stepik.org/course/530",
    "Основы функционального тестирования — Udemy": "https://www.udemy.com/course/functional-testing/"
  },
  "Тестирование пользовательского интерфейса": {
    "UI тестирование — Coursera": "https://www.coursera.org/learn/ui-testing",
    "Тестирование интерфейсов — Udemy": "https://www.udemy.com/course/ui-testing/"
  },
  "автотест": {
    "Автоматизация тестирования — Stepik": "https://stepik.org/course/530",
    "Автотестирование — Coursera": "https://www.coursera.org/learn/automated-testing"
  },
  "Проведение тестирований": {
    "Методы тестирования — Udemy": "https://www.udemy.com/course/software-testing-methods/",
    "Проведение тестов — Coursera": "https://www.coursera.org/learn/software-testing"
  },
  "Уверенный пользователь ПК": {
    "Компьютерная грамотность — Stepik": "https://stepik.org/course/73",
    "Основы работы с ПК — Coursera": "https://www.coursera.org/learn/computer-literacy"
  },
  "Знание программы 1С": {
    "Основы работы в 1С — Stepik": "https://stepik.org/course/1",
    "1С для начинающих — Udemy": "https://www.udemy.com/course/1c-for-beginners/"
  },
  "Знание 1С Предприятие": {
    "1С:Предприятие для начинающих — Stepik": "https://stepik.org/course/1",
    "Работа в 1С:Предприятие — Udemy": "https://www.udemy.com/course/1c-enterprise/"
  },
  "приходные и расходные операции": {
    "Учет операций в 1С — Stepik": "https://stepik.org/course/1",
    "Финансовый учет в 1С — Udemy": "https://www.udemy.com/course/1c-financial-accounting/"
  },
  "Обновление конфигурации 1С": {
    "Обновление конфигураций в 1С — Stepik": "https://stepik.org/course/1",
    "Управление конфигурациями 1С — Udemy": "https://www.udemy.com/course/1c-configuration-management/"
  },
  "Создание конфигурации 1С": {
    "Создание конфигураций в 1С — Stepik": "https://stepik.org/course/1",
    "Разработка конфигураций 1С — Udemy": "https://www.udemy.com/course/1c-configuration-development/"
  },
  "Разработка расширений": {
    "Разработка расширений в 1С — Stepik": "https://stepik.org/course/1",
    "Создание расширений 1С — Udemy": "https://www.udemy.com/course/1c-extension-development/"
  },
  "Готовность к командировкам": {
    "Эффективные командировки — Coursera": "https://www.coursera.org/learn/effective-business-travel",
    "Планирование командировок — Udemy": "https://www.udemy.com/course/business-travel-planning/"
  },
  "Ответственный подход к работе": {
    "Развитие ответственности — Coursera": "https://www.coursera.org/learn/responsibility-development",
    "Ответственность на работе — Udemy": "https://www.udemy.com/course/workplace-responsibility/"
  },
  "С++": {
    "C++ для начинающих — Stepik": "https://stepik.org/course/363",
    "Современный C++ — Coursera": "https://www.coursera.org/learn/c-plus-plus-modern-development"
  },
  // Прочее
  "Английский — A2 — Элементарный": {
    "Английский язык для начинающих — Duolingo": "https://www.duolingo.com/course/en/ru/Learn-English",
    "Английский язык A2 — Lingualeo": "https://lingualeo.com/ru"
  },
  "SOLID": {
    "SOLID ПРИНЦИПЫ простым языком (много примеров) — YouTube": "https://www.youtube.com/watch?v=TxZwqVTaCmA",
    "От новичка до профессионала: Принципы SOLID для разработчиков — CourseHunter": "https://coursehunter.net/course/ot-novichka-do-professionala-principy-solid-dlya-razrabotchikov-na-c",
    "Принципы SOLID на примерах — Хабр": "https://habr.com/ru/articles/688530/"
  },
  "Проектный менеджмент": {
    "Основы управления проектами — Coursera": "https://www.coursera.org/learn/project-management-principles",
    "Управление проектами — Stepik": "https://stepik.org/course/1004"
  },
  "ASO": {
    "Бесплатный видеокурс «Освой все тонкости ASO» — ASOdesk": "https://ru.asodesk.com/free-video-course/",
    "Бесплатный курс «ASO для начинающих» — Asodesk": "https://ru.asodesk.com/email_course",
    "ASO Академия — ASOMobile": "https://asomobile.net/aso-akademiya/"
  }




  
};
  