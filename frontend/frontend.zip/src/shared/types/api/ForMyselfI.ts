export interface WantedProfessionCreateI {
  id_profession: number
  user_id: number
}
