fnm env --use-on-cd --shell powershell | Out-String | Invoke-Expression

npm run dev